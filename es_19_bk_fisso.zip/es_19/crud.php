<?php
    include "usefull/connection.php";
    include "usefull/dbCommand.php";
    include "usefull/session.php";
    include "usefull/cookie.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <link rel = 'stylesheet' href='style/indexStyle.css'>
    <title>Registrazione Pillitu.it</title>
</head>
<body class = "<?php echo $_COOKIE["background"]?> ">

    <?php
        //controllo della sessione
        issetSession();
        //print della crud per le azioni dei bottoni nella pagina
        printCrud();
        

        $connection = connectToDatabase("my_esercizipillitu");

        $operation = $_GET["operation"];

        switch($operation) {
            case "READ":
                    readData($connection);
                break;

            case "UPDATE":
                update_menu($connection);
                break;
            case "UPDATE_USER":

                if(!empty($_POST['old_psw']) && !empty($_POST['new_psw']))
                check_new_psw($connection);
                else {
                    $new_name = $_POST['new_name'];
                    $new_surname = $_POST['new_surname'];
                    $new_sex = null;
                    $new_region = $_POST['new_region'];
                    $new_date = $_POST['new_date'];

                    if (isset($_POST['new_sex']))
                        $new_sex = $_POST['new_sex'];

                    // aggiornamento dei campi che l'utente ha riempito
                    $queryUpdate = "UPDATE utenti SET ";
                    $queryUpdate = check_new_value($connection, $queryUpdate, $new_name, $new_surname, $new_sex, $new_region, $new_date);
                    $queryUpdate .= "WHERE id = '" . $_SESSION['id_user'] . "'";
                    
                    $resQueryUpdate = dbQuery($connection, $queryUpdate);

                    if ($resQueryUpdate) {
                        echo "<br>Modifiche eseguite con successo";
                        header("Refresh: 5; URL=crud.php?operation=READ"); 
                    } else {
                        echo "<br>Errore, riprova piú tardi";
                        header("Refresh: 5; URL=index.php"); 
                    }
                }
                break;
            case "DELETE":
                    delete($connection);
                break;

            case "LOGOUT":
                    logout();
                break;
        }
    ?>

</body>