<?php
    include "usefull/connection.php";
    include "usefull/dbCommand.php";
    include "usefull/cookie.php";
//metodo presente in connection --> apposito per compiere la connection al db
    $connection = connectToDatabase("my_esercizipillitu");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <link rel = 'stylesheet' href='style/indexStyle.css'>
    <title>Registrazione Pillitu.it</title>
    

    <style>
        body {
            font-family: 'Arial', sans-serif;
           /* border : 1px solid black;
          /*  background-color: #f4f4f4;*/
            margin: 0;
            display: flex;
            justify-content: center;
            /*align-items: center;*/

            
        }

        form {
            position: absolute;
            background-color: grey;
            padding: 3%;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 40%;
            border : 1px solid black;
            top : 5%;
 
        }

        label {
            margin-bottom: 5%;
        }

        input, select, textarea {
            width: 100%;
            padding: 2%;
            margin-bottom: 4%;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 1%;
        }

        textarea {
            resize: vertical;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            cursor: pointer;
            padding: 2%;
            border: none;
            border-radius: 4px;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
        /*set dello style del cookie : */
        .switch {
                position: absolute;
                top: 10%;
                right: 15%;
                display: inline-block;
                width: 3%;
                height: 3%;
            }

            .switch input {
                opacity: 0;
                width: 0;
                height: 0;
            }

            .slider {
                position: absolute;
                cursor: pointer;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background-color: <?php echo ($_COOKIE["background"]=="white"? "#ccc" : "#04AA6D")?>;
                -webkit-transition: .4s;
                transition: .4s;
            }

            input:checked + .slider {
                background-color: <?php echo ($_COOKIE["background"]=="white"? "#cac" : "#04AC9D"); ?>;
            }

            /* solo se Rounded sliders gli viene applicato un bordo */
            .slider.round {
                border-radius: 34px;
            }

    </style>
</head>

<body class = "<?php echo $_COOKIE["background"]?> ">

    <form method="post" action="register.php" id="inputForm">
<!-- Inserimento dell' email -->
        <label>Email : </label>
        <!-- Inserimento dell' email chiamata la funzione prova mail per controllare se è gia presente la mail-->
        <input type="email" name="email" onkeyup="provaMail(this)" required >
        <p id="status">inserire mail </p>
<!-- Creazione della password -->
        <label>Password : </label>
        <input type="password" name="password" required>
        <br><br><br>

<!-- Inserimento di nome e cognome -->
        <label>Nome : </label>
        <input type="text" name="name" required>
        <label>Cognome : </label>
        <input type="text" name="surname" required>
        <br><br>
        
<!-- Inserimento del sesso -->
        <label>Sesso :<br><br></label>
        
        <label>Uomo</label>
        <input type="radio" name="sex" value="M" checked>
        <label>Donna</label>
        <input type="radio" name="sex" value="F">
        <br><br>
        
        
<!-- Inserimento del/dei titolo/i di studio -->
        <label>Titolo di studio : <br></label>
        <?php 
            $query1 = "SELECT codice, nome FROM titolidistudio ORDER BY nome ASC";
            $queryTitoli = dbquery($connection, $query1);

            if (($queryTitoli -> num_rows) > 0) {
                while ($row = $queryTitoli -> fetch_assoc()) {
                    echo "<input type='checkbox' value='" . $row['codice'] . "' name='titoliDiStudio[]'>";
                    echo "<label for='" . $row['codice'] . "'>" . $row['nome'] . "<br>";
                }
            } else 
                echo "Tabella 'titoli di studio' vuota";
        ?>
        
<!-- Inserimento della regione -->
        <label><br> Regione di residenza : <br></label>
        <select name="region">
            <?php 
                $query2 = "SELECT codice, nome FROM regioni ORDER BY nome ASC";
                $queryRegioni = dbquery($connection, $query2);

                if (($queryRegioni -> num_rows) > 0) {
                    while ($row = $queryRegioni -> fetch_assoc()) {
                        echo "<option value='" . $row['codice'] . "'>" . $row['nome'] . "</option>";
                    }
                } else 
                echo "Tabella 'regioni' vuota";
            ?>
        </select><br><br>

<!-- Inserimento della data di nascita -->
        <label>Data di nascita : <br></label>
        <input type="date" name="birthDate" id="birthDate" required>
        <br><br>
        
<!-- Note ulteriori -->
        <label>Note</label><br>
        <textarea cols="30" rows="10" placeholder="scrivi il tuo commento a Pillitu.it" name="notes"></textarea>
        
        <br><br><br><br><input id="sub" type="submit" value="INVIA">
    </form>

    <script>
//per non far inserire date che non sono ancora passate :
        document.addEventListener("DOMContentLoaded", function() {
            let inputForm = document.getElementById("inputForm");

            inputForm.addEventListener("submit", function(event) {
                let inputDate = document.getElementById("birthDate");
                let formatInputDate = new Date(inputDate.value);
                let today = new Date();

                if (formatInputDate > today) {
                    alert("Non puoi inserire una data di nascita futura");
                    inputDate.value = "";
                    event.preventDefault(); // Impedisce l'invio del modulo
                }
            });
        });
    </script>
</body>
</html>

<script>
   
   var checkbox = document.querySelector('input[value="LME"]');
    checkbox.checked = true;


    //funzione per controllare la mail
    function provaMail(elem) {
            const text = elem.value
            const status = document.getElementById("status")//scritta
            const sub = document.getElementById("sub") //pulsante submit

            if (text.length == 0) {
                status.innerText = "Inserire indirizzo"
                status.style.color = "black"
                sub.disabled = true //pulsante disabilitato
                return
            }
            //ajax
            const xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() { //controlla lo status code che manda il php e se 200 quini ok sblocca il pulsante
                if (this.readyState == 4) {
                    if (this.status === 200) {
                        status.innerText = "Indirizzo valido"
                        status.style.color = "green"
                        sub.disabled = false
                    } else {
                        status.innerText = "Indirizzo non valido o già in uso"
                        status.style.color = "red"
                        sub.disabled = true
                    }
                }
            };
            //il get in check mail "address " --> dipende ?address --> se cambio address cambia anche il get nel php
            xmlhttp.open("GET", "usefull/checkMail.php?address=" + text, true);
            xmlhttp.send();
        }
</script>