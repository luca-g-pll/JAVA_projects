

//funzione per mostrare o meno la password
            function mostraPassword() {
                if(document.getElementById("psw").type == "password"){
                    document.getElementById("psw").type = "text";
                }else
                {
                    document.getElementById("psw").type = "password";
                }  
            }
