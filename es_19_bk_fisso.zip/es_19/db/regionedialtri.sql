-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Feb 19, 2024 alle 10:44
-- Versione del server: 10.4.28-MariaDB
-- Versione PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `regionedialtri`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `regioni`
--

CREATE TABLE `regioni` (
  `codice` varchar(30) NOT NULL,
  `nome` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `regioni`
--

INSERT INTO `regioni` (`codice`, `nome`) VALUES
('ABR', 'Abruzzo'),
('BAS', 'Basilicata'),
('CAL', 'Calabria'),
('CAM', 'Campania'),
('EMR', 'Emilia Romagna'),
('FVG', 'Friuli-Venezia Giulia'),
('LAZ', 'Lazio'),
('LIG', 'Liguria'),
('LOM', 'Lombardia'),
('MAR', 'Marche'),
('MOL', 'Molise'),
('PIE', 'Piemonte'),
('PUG', 'Puglia'),
('SAR', 'Sardegna'),
('SIC', 'Sicilia'),
('TAA', 'Trentino-Alto Adige'),
('TOS', 'Toscana'),
('UMB', 'Umbria'),
('VDA', 'Valle d\'Aosta'),
('VEN', 'Veneto');

-- --------------------------------------------------------

--
-- Struttura della tabella `titolidistudio`
--

CREATE TABLE `titolidistudio` (
  `codice` varchar(30) NOT NULL,
  `nome` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `titolidistudio`
--

INSERT INTO `titolidistudio` (`codice`, `nome`) VALUES
('DSS', 'Diploma Scuola Superiore'),
('LMA', 'Laurea Magistrale'),
('LME', 'Licenza Media'),
('LTR', 'Laurea Triennale'),
('MAS', 'Master'),
('MSS', 'Master di secondo livello');

-- --------------------------------------------------------

--
-- Struttura della tabella `username_password`
--

CREATE TABLE `username_password` (
  `id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `id_utente` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `username_password`
--

INSERT INTO `username_password` (`id`, `username`, `password`, `id_utente`) VALUES
(1, 'luca.pillitu.5@outlook.it', '359ee8d482d3cac0fdffb2b83df30b9aabb2f265896ec61f93bbc94d77115a67', 1),
(2, 'kgtzzqgmnozkrujtmt@awdrt.com', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', 2),
(7, 'ciao@gmail.com', '6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918', 7);

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

CREATE TABLE `utenti` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `cognome` varchar(50) DEFAULT NULL,
  `sesso` char(1) DEFAULT NULL,
  `codice_regione` varchar(30) DEFAULT NULL,
  `dataDiNascita` date DEFAULT NULL,
  `note` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`id`, `nome`, `cognome`, `sesso`, `codice_regione`, `dataDiNascita`, `note`) VALUES
(1, 'luca', 'pillitu', 'M', 'PIE', '2023-01-06', ''),
(2, 'napo', 'cirke', 'F', 'LOM', '2024-01-04', ''),
(7, 'ciao', 'pillitu', 'M', 'ABR', '2024-01-31', '');

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti_titoli`
--

CREATE TABLE `utenti_titoli` (
  `id_utente` int(11) DEFAULT NULL,
  `codice_titolo` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `utenti_titoli`
--

INSERT INTO `utenti_titoli` (`id_utente`, `codice_titolo`) VALUES
(1, 'DSS'),
(1, 'LMA'),
(1, 'LTR'),
(2, 'LME'),
(7, 'DSS');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `regioni`
--
ALTER TABLE `regioni`
  ADD PRIMARY KEY (`codice`);

--
-- Indici per le tabelle `titolidistudio`
--
ALTER TABLE `titolidistudio`
  ADD PRIMARY KEY (`codice`);

--
-- Indici per le tabelle `username_password`
--
ALTER TABLE `username_password`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `id_utente` (`id_utente`);

--
-- Indici per le tabelle `utenti`
--
ALTER TABLE `utenti`
  ADD PRIMARY KEY (`id`),
  ADD KEY `codice_regione` (`codice_regione`);

--
-- Indici per le tabelle `utenti_titoli`
--
ALTER TABLE `utenti_titoli`
  ADD KEY `id_utente` (`id_utente`),
  ADD KEY `codice_titolo` (`codice_titolo`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `username_password`
--
ALTER TABLE `username_password`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT per la tabella `utenti`
--
ALTER TABLE `utenti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `username_password`
--
ALTER TABLE `username_password`
  ADD CONSTRAINT `username_password_ibfk_1` FOREIGN KEY (`id_utente`) REFERENCES `utenti` (`id`);

--
-- Limiti per la tabella `utenti`
--
ALTER TABLE `utenti`
  ADD CONSTRAINT `utenti_ibfk_1` FOREIGN KEY (`codice_regione`) REFERENCES `regioni` (`codice`);

--
-- Limiti per la tabella `utenti_titoli`
--
ALTER TABLE `utenti_titoli`
  ADD CONSTRAINT `utenti_titoli_ibfk_1` FOREIGN KEY (`id_utente`) REFERENCES `utenti` (`id`),
  ADD CONSTRAINT `utenti_titoli_ibfk_2` FOREIGN KEY (`codice_titolo`) REFERENCES `titolidistudio` (`codice`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
