<?php
    include "usefull/dbCommand.php";
    include "usefull/cookie.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>loginPillitu.it</title>
    <script src="js/util.js"></script>
    <link rel = 'stylesheet' href='style/indexStyle.css'>
    <style>
        body{
            font-family: 'Arial', sans-serif;
            margin: 10%;
            justify-content: center;
            align-items: center;
            height: 50%;
        }
    </style>
</head>
<body class = "<?php echo $_COOKIE["background"]?> ">
    <!-- Form per effettuare il login se gia registrati e viene richiatao il file php per il login effettivo-->
    <H2>LOGIN</H2>
        <form method="post" action="login.php">

    <!-- Inserimento dell'email -->
            <label>Email : </label><br>
            <input type="email" name="email" required>

    <!-- Inserimento della password -->
            <label><br><br>Password :   
                <input type="checkbox"  onclick="mostraPassword()">
                <label for="ckpsw">Mostra</label>
            </label><br>
            <input type="password" name="password" id="psw" maxLenght="25" required>
            <br><br><br>
            <input type="submit" value="ACCEDI">
        </form>

    <!-- Form per effettuare la registrazione se non gia registrati - nel caso non sia registrato -->
        <form method="post" action="indexRegister.php" id="registrati">
            <br><br><br><br>
            <label>Non sei ancora registrato?  <input type="submit" value="Registrati"> </label>
        </form>

</body>
</html>

