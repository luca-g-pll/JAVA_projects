<?php
    include "usefull/connection.php";
    include "usefull/dbCommand.php";
    include "usefull/session.php";
    include "usefull/cookie.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <link rel = 'stylesheet' href='style/indexStyle.css'>
    <title>Registrazione Pillitu.it</title>
</head>
<body class = "<?php echo $_COOKIE["background"]?> ">
    <?php
        
        
        

        $connection = connectToDatabase("my_esercizipillitu");

        $email = $_POST["email"];
        $psw = $_POST["password"];
        
        $psw = hash('sha256',$psw);
        $id_utente;


        $query1 = "SELECT username, password, id_utente 
                    FROM username_password
                    WHERE username = '".$email."' AND password = '".$psw."'";

        //echo $query1;
        $getData = dbQuery($connection, $query1);

        // controllo se la password inserita nel db é uguale a quella appena inserita criptandola con la stessa tecnica
        if ($getData-> num_rows > 0) {
            while ($row = $getData->fetch_assoc()) {
                //controllo l'inserimento della password con quella precedentremente criptata tramite hashing delle due (non posso decripatare l'hash)
                //metodo di confronto degli hash non potendo decriptare viene più semplice questa maniera
               // if (hash('sha256', $psw) === $row['password']) {
                    //echo "Login effettuato con successo !<br>";
                    $id_utente = $row['id_utente'];

                    //echo "Host : ".$id_utente."<br> L'id della sessione è : ".session_id()."<br><br><br>";

                    $_SESSION["id_user"] = $id_utente;
                    
                    echo "<H1 style=\"position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color : green;\">Login accettato</H1>";
                    header("Refresh: 2; URL= loginCrud.php");
        
                
            }
        } else {
            echo "<H1 style=\"position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color : red;\">Login fallito</H1>";
            header("Refresh: 2; URL= index.php");
            exit;
        }

        /* ALTERNATIVAMNETE SI POTEVA FARE --> PER CONTROLALRE L'HASH
        bisogna prima prendere gli hash e poi chiedere il login
            decripstare la funzione cript(crea un hash non reversibile) --> paragona i due hash (senza ritrasformare nulla)
            $stored_hash = '$2y$10$YourStoredHashHere'; // Sostituisci con l'hash memorizzato nel tuo database

        $user_provided_password = 'password123'; // Sostituisci con la password fornita dall'utente

        if (password_verify($user_provided_password, $stored_hash)) {
            echo 'La password è corretta!';
        } else {
            echo 'La password non è corretta.';
    }
    */
    ?>
</body>