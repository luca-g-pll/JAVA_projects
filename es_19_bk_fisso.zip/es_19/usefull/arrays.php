<?php
    $region = array("VDA" => "Valle D'Aosta",
                    "PIE" => "Piemonte",
                    "LOM" => "Lombardia",
                    "TAA" => "Trentino-Alto Adige",
                    "FVG" => "Fiuli-Venezia Giulia",
                    "VEN" => "Veneto",
                    "LIG" => "Liguria",
                    "EMR" => "Emilia Romagna",
                    "TOS" => "Toscana",
                    "MAR" => "Marche",
                    "UMB" => "Umbria",
                    "LAZ" => "Lazio",
                    "ABR" => "Abruzzo",
                    "MOL" => "Molise",
                    "CAM" => "Campania",
                    "PUG" => "Puglia",
                    "BAS" => "Basilicata",
                    "CAL" => "Calabria",
                    "SIC" => "Sicilia",
                    "SAR" => "Sardegna"
                );

    $education = array("LME" => "Licenza Media",
                        "DSS" => "Diploma Scuola Superiore",
                        "LTR" => "Laurea Triennale",
                        "LMA" => "Laurea Magistrale",
                        "MAS" => "Master",
                        "MSS" => "Master di secondo livello");

    $day = array("Monday" => "Lunedi", 
                "Tuesday" => "Martedi", 
                "Wednesday" => "Mercoledi", 
                "Thursday" => "Giovedi",
                "Friday" => "Venerdi", 
                "Saturday" => "Sabato", 
                "Sunday" => "Domenica");

    $month = array("January" => "Gennaio", 
                    "February" => "Febbraio", 
                    "March" => "Marzo", 
                    "April" => "Aprile", 
                    "May" => "Maggio", 
                    "June" => "Giugno", 
                    "July" => "Luglio", 
                    "August" => "Agosto", 
                    "September" => "Settembre", 
                    "October" => "Ottobre", 
                    "November" => "Novembre", 
                    "December" => "Dicembre");
?>