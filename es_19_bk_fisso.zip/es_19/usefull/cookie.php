<?php
    include "session.php";

    if(!isset($_COOKIE["background"])){
        setcookie("background", "body", time() + (864000 * 30)); // 86400 = 1 day
    }
?>

<html>
    <head>
        <link rel = 'stylesheet' href='../style/indexStyle.css'>
    </head>
    <body id = "body">
        <label class = "dm"style = "right: 7%">Dark Mode</label>
        <label class="dm">
            <input type="checkbox" name="mode" id="mode" <?php if($_COOKIE["background"]=="dark") echo "checked" ?>>
        </label>
    </body>
</html>

<script>
    var dmbutton = document.getElementById('mode');
    var body = document.getElementById('body');

    dmbutton.addEventListener("click",function(){
        if(dmbutton.checked){
            document.cookie = "background = dark; expires=" + (new Date(Date.now() + (86400000 * 30)).toUTCString());
            body.classList.add("dark");
        }else{
            document.cookie = "background = body; expires=" + (new Date(Date.now() + (86400000 * 30)).toUTCString());
            body.classList.remove("dark");
        }
    });
</script>
