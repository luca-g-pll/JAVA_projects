<?php
    include "dbCommand.php";
    include "connection.php";


    if (!isset($_GET["address"])) {
        http_response_code(204);
        exit();
    }
    
    $conn = connectToDatabase("my_esercizipillitu");
    $query = "SELECT EXISTS(SELECT * FROM username_password WHERE username = \"" . $_GET["address"] . "\")";
    $r = dbquery($conn, $query);

    
    if (!$r || $r->num_rows <= 0) {
        http_response_code(500);
        exit();
    }
    
    $exists = $r->fetch_row()[0];
    
    if ($exists) {
        http_response_code(406);
        exit();
    }
    
    if(!filter_var($_GET["address"], FILTER_VALIDATE_EMAIL)) {
        http_response_code(406);
        exit();
    }
    
    http_response_code(200);
    exit();

?>