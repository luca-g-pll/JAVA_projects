<?php 

    function issetSession(){
                //se la session non è impostata riporta alla pagina del login
                if(!isset($_SESSION["id_user"])){
                    echo "<H1 style=\"position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color : red;\">Login fallito</H1>";
                    header("Refresh: 2; URL= index.php");
                }
    }    


// funzione per eseguire una query sul database, INVIANDOGLIELA
    function dbQuery($connection, $query) {
        return $connection -> query($query);
    }

// funzione che da un array restituisce una tabella html, formattando la data
    function createTable($result) {
        if ($result === false)
            echo "Errore nella query.";
        else {
            if ($header = $result->fetch_assoc()) {
                // creazione della tabella
                echo "<table border='1'>";
                    // creazione dell'header con i nomi delle colonne
                    echo "<tr>";
                        foreach ($header as $key => $value)
                            echo "<th>" . $key . "</th>";
                    echo "</tr>";

                    // inserimento della prima riga (quella appena inserita)
                    echo "<tr>";
                        foreach ($header as $key => $value) {
                            printField($key, $value);
                        }
                    echo "</tr>";

                // inserimento delle altre righe della tabella
                while($header = $result->fetch_assoc()) {
                    echo "<tr>";
                        foreach ($header as $key => $value) {
                            printField($key, $value);
                        }
                    echo "</tr>";
                }

                echo "</table>";
            } else {
                echo "Nessun risultato trovato.";
            }
        }
    }

// funzione per controllare se il campo é una data, e se lo é lo formatta correttamente
    function printField($key, $value) {
        include "arrays.php";

        switch($key) {
            case "dataDiNascita":
                 return $date = date('d/m/Y', strtotime($value));
                
                break;

            case "codice_regione":
                return  $region[$value] ;
                break;

            case "sesso":
                if ($value === "M")
                    return "Maschio";
                else 
                    return "Femmina";
                break;

            default:
                return  $value ;
                break;
        }
    }


    function logout(){
        
        session_unset(); //dealloca l'array della sessione
        header("Location: index.php");
        exit();
    }



    function delete($connection){
        $query2 = "DELETE FROM username_password
                            WHERE id_utente = '".$_SESSION["id_user"]."';";
                $query3 = "DELETE FROM utenti_titoli 
                            WHERE id_utente = '".$_SESSION["id_user"]."';";
                $query4 = "DELETE FROM utenti 
                            WHERE id = '".$_SESSION["id_user"]."';";

                $delQuery3 = dbQuery($connection, $query2);
                $delQuery1 = dbQuery($connection, $query3);
                $delQuery2 = dbQuery($connection, $query4);

                if ($delQuery1 === TRUE && $delQuery2 === TRUE && $delQuery3 === TRUE)
                    echo "<script>alert('Account eliminato con successo');</script>";

                logout();
    }


    //metodo per la creazione dei bottoni crud
    function printCrud(){
        echo "              <button> <a href='indexRegister.php'> CREATE </a>         </button>
                            <button> <a href='crud.php?operation=READ'> READ </a>     </button>
                            <button> <a href='crud.php?operation=UPDATE'> UPDATE </a> </button>
                            <button> <a href='crud.php?operation=DELETE'> DELETE </a> </button>
                            <button> <a href='crud.php?operation=LOGOUT'> LOGOUT </a> </button>";
    }


//metodo per la stampa dei dati 
    function readData($connection){
        $query1 = " SELECT username_password.username, utenti.nome, utenti.cognome, utenti.sesso, utenti.codice_regione, utenti.dataDiNascita, utenti.note
                            FROM utenti 
                            INNER JOIN 	username_password on utenti.id = username_password.id
                            WHERE utenti.id = '".$_SESSION["id_user"]."';";

        $read = dbQuery($connection, $query1);

                if ($read->num_rows > 0) {
                    echo "<table style =\"border: 1px solid black; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);\">
                            <tr>    
                                    <th> mail : </th><th> nome : </th><th>cognome : </th>
                                    <th> sesso : </th><th> regione : </th><th> nascita : </th>
                                    <th> note : </th>                
                            </tr>";
                    // output data of each row
                    while($row = $read->fetch_assoc()) {
                        echo "<tr>
                                    <td style ='border: 1px solid black; text-align : left;'>" . " ".$row["username"]." ". "</td>
                                    <td style ='border: 1px solid black; text-align : left;'>" . $row["nome"]. "</td>
                                    <td style ='border: 1px solid black;text-align : right;'>" . $row["cognome"] ."</td>
                                    <td style ='border: 1px solid black;text-align : right;'>" . printField("sesso",$row["sesso"]) . "</td>
                                    <td style ='border: 1px solid black;'>" . printField("codice_regione",$row["codice_regione"]). "</td>
                                    <td style ='border: 1px solid black;'>" . printField("dataDiNascita",$row["dataDiNascita"]) . "</td>
                                    <td style ='border: 1px solid black;'>" . $row["note"]. "</td>
                            </tr>";
                    }
                    echo "</table>";
                } else {
                    echo "<br>-Tabella non raggiungibile :(";
                }

    }

//metodo per la modifica dei dati
    function update_menu($connection) {
                readData($connection);
                
        echo "<br><br><br>Cosa vuoi modificare?<br><br>";

        echo "<form method='POST' action='crud.php?operation=UPDATE_USER'>";
            echo "Modifica il tuo nome ";
            echo "<input type='text' name='new_name'>";

            echo "<br><br>Modifica il tuo cognome ";
            echo "<input type='text' name='new_surname'><br><br>";

            echo "Vuoi cambiare il sesso inserito?";
            echo "<br><label>SI</label>";
            echo "<input type='checkbox' name='new_sex' value='S'>";

            echo "<br><br>Modifica la regione di residenza ";
            echo "<select name='new_region'>";
                    $queryR = "SELECT codice, nome
                                        FROM regioni";
                    $resQueryR = dbQuery($connection, $queryR);

                    if ($resQueryR) {
                        if (($resQueryR -> num_rows) > 0) {
                                echo "<option>---</option>";
                            while ($row = $resQueryR -> fetch_assoc())
                                echo "<option value='" . $row['codice'] . "'>" . $row['nome'] . "</option>";      
                        } else 
                            echo "<option>Nessuna regione disponibile</option>";
                    } else
                        echo $connection->error;
            echo "</select>";

            echo "<br><br>Modifica la data di nascita ";
            echo "<input type='date' name='new_date' onclick='checkInputDate()'>";

            echo "<br><br>Inserisci la vecchia password ";
            echo "<input type='password' name='old_psw'>";
            echo "<br><br>Inserisci la nuova password ";
            echo "<input type='password' name='new_psw'>";

            echo "<br><br><br><input type='submit' value='Esegui'>";
        echo "</form>";
    }


     // funzione per controllare che la password che sto cambiando sia uguale alla precedente per cambiare la nuova
    function check_new_psw($connection) {
        $old_psw = $_POST['old_psw'];
        $new_psw = $_POST['new_psw'];

        if ($old_psw === $new_psw) {
            echo "<br>Le due password non possono essere uguali, stai per essere reindirizzato indietro...<br>";
            header("Refresh: 5; URL=crud.php?operation=UPDATE");
        } else {
            $queryPsw = "SELECT password
                            FROM username_password
                            WHERE id_utente = '" . $_SESSION['id_utente'] . "'";
            $resQueryPsw = dbQuery($connection, $queryPsw);
            
            if ($resQueryPsw->num_rows > 0) {
                while ($row = $resQueryPsw->fetch_assoc()) {
                    if (check_password($row['password'], $old_psw)) {
                        $queryUpdatePsw = "UPDATE username_password
                                            SET password = SHA2('$new_psw', 256)
                                            WHERE id_utente = '" . $_SESSION['id_utente'] . "'";
                        $resUpdatePsw = dbQuery($connection, $queryUpdatePsw);

                        if($resUpdatePsw) {
                            echo "Password aggiornata con successo<br><br>";
                            crud_menu();
                        } else 
                            echo "Si é verificato un errore, riprova piú tardi";
                    } else {
                        echo "La vecchia password non corrisponde, riprova...";
                        header("Refresh: 5; URL=crud.php?operation=UPDATE");
                    }
                }
            }
        }
    }



     // funzione per controllare che i campi non siano vuoti
    function check_new_value($connection, $queryUpdate, $new_name, $new_surname, $new_sex, $new_region, $new_date) {
        if (!empty($new_name))
            $queryUpdate .= "nome = '$new_name',";
        
        if (!empty($new_surname))
            $queryUpdate .= "cognome = '$new_surname',";
        
        if (isset($new_sex)) {
            if ($_POST['new_sex'] == 'S') {
                $queryUpdateS = "SELECT sesso
                                FROM utenti
                                WHERE id = '" . $_SESSION['id_user'] . "'";
                $resUpdate = dbQuery($connection, $queryUpdateS);

                if (($resUpdate -> num_rows) > 0) {
                    while ($row = $resUpdate -> fetch_assoc()) {
                        if ($row['sesso'] == "M")
                            $queryUpdate .= "sesso = 'F',";
                        else
                            $queryUpdate .= "sesso = 'M',";
                    }
                }
            }     
        }
        if ($new_region != '---')
            $queryUpdate .= "codice_regione = '$new_region',";

        if (!empty($new_date))
            $queryUpdate .= "dataDiNascita = '$new_date',";

        $queryUpdate = rtrim($queryUpdate, ", ");

        return $queryUpdate;
    }
?>