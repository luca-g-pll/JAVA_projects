<?php
    include "usefull/connection.php";
    include "usefull/arrays.php";
    include "usefull/dbCommand.php";
    //include "usefull/cookie.php";

    // connessione al database
    $connection = connectToDatabase("my_esercizipillitu");


// ottengo i valori dei vari input dati dal form html
//informazioni utili al login successivo :     
    $email = $_POST['email'];
    $password = $_POST['password'];
//informazioni futili
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $sex = $_POST['sex'];
    $educationIn = $_POST['titoliDiStudio'];
    $regionIn = $_POST['region'];
    $birthDate = $_POST['birthDate'];
    $notes = $_POST['notes'];

// stampa di nome e cognome
echo "<H1 style=\"position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color : green;\">Registrazione avvenuta con Successo</H1>";
header("Refresh: 2; URL= index.php");
    
    
// stampa del titolo/i di studio
    if (isset ($educationIn)) {
        
        $outEducation = "";
        foreach ($educationIn as $value)
            $outEducation .= " " . $education[$value] . ";";

        $outEducation = substr($outEducation, 0, (strlen($outEducation) - 1));

        echo $outEducation;
    }

// stampa della regione di residenza
   // echo "<br><br>Sei residente in : " . $region[$regionIn] . ". <br><br>";

// formattazione e stampa della data di nascita
    //$date = new DateTime($birthDate);

// aggiunta dell'utente al db nella tabella utenti
    $query1 = "INSERT INTO utenti(nome, cognome, sesso, codice_regione, dataDiNascita, note)
                VALUES ('$name', '$surname', '$sex', '$regionIn', '$birthDate', '$notes')";
    $insert1 = dbQuery($connection, $query1);

    if ($insert1 === TRUE) {
        $id_utente = $connection -> insert_id;

        foreach ($educationIn as $value) {
            $query2 = "INSERT INTO utenti_titoli(id_utente, codice_titolo)
                        VALUES('$id_utente', '$value')";
            $insert2 = dbQuery($connection, $query2);
        }

        // aggiunta dell'utente appena creato nella tabella contenente username e password
        try {
            //funzinone .crypt()
            $query3 = "INSERT INTO username_password(username, password, id_utente)
                        VALUES ('$email', SHA2('$password', 256), $id_utente)";// il metodo SHA2 usa l'algoritmo di criptazione 'md5' usato da php / differente da 'DES', 'Blowfish'
            $insert3 = dbQuery($connection, $query3);




            /*diversamente utilizzata la funzione sha2 --> 
                $salt = random_bytes(32); // Genera un salt casuale di 32 byte
                $hashedPassword = hash('sha256', $password . $salt);

                OPPRUE

                // Calcola l'hash SHA-256 e converte in esadecimale
                    $hash = hash('sha256', $stringaOriginale, true); // il parametro true indica output binario
                    $hashHex = bin2hex($hash); --> TRASFORMA DA BIN A HEX
            */
            echo "<br><br><br><button><a href='indexRegister.php'>Inserisci un nuovo utente</a></button>";
            echo "<br><br>Effettua il login cliccando il bottone<br>";
            echo "<button><a href='index.php'>LOGIN</a></button>";
        } catch (mysqli_sql_exception $e) {
            ob_clean(); //metodo per pulire il buffer di output in uso,utile per non creare problemi durante altri invii successivi

            echo "UTENTE GIA REGISTRATO";
            echo "<br><br>Effettua il login cliccando il bottone<br>";
            echo "<button><a href='index.php'>LOGIN</a></button>";

            $deleteTitoliQuery = "DELETE FROM utenti_titoli WHERE id_utente = '$id_utente'";
            $deleteUtenteQuery = "DELETE FROM utenti WHERE id = '$id_utente'";
            $delete1 = dbQuery($connection, $deleteTitoliQuery);
            $delete2 = dbQuery($connection, $deleteUtenteQuery);
        }
    } else
        echo "Qualcosa é andato storto, riprova piú tardi.";
?>