<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=, initial-scale=1.0">
        <link rel = 'stylesheet' href='style/indexStyle.css'>
        <title>Registrazione Pillitu.it</title>
    </head>
    <body class = "<?php echo $_COOKIE["background"]?> ">
        <?php

        include "usefull/connection.php";
        include "usefull/dbCommand.php";
        include "usefull/session.php";
        include "usefull/cookie.php";



                echo"<div style=\"position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);\">";
                // area personale per visualizzare i dati inseriti - MENU CRUD
                echo"<label>Quale operazione vuoi eseguire sul DataBase ? <br><br></label>";
                printCrud();

                echo"</div>";

        ?>

    </body>
</html>