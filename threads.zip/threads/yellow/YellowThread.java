package yellow;

public class YellowThread extends Thread implements Runnable
{
    private double a;
    private double b;
    private double c;
    private double result;

    public YellowThread(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public double getResult() 
    {
        return result;
    }

    @Override
    public void run() 
    {
        YellowdarkThread yellowdarkThread = new YellowdarkThread(a, b, c);
        YellowlightThread yellowlightThread = new YellowlightThread(a, b, c);
        yellowdarkThread.start();
        yellowlightThread.start();
        try {
            yellowdarkThread.join();
            yellowlightThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        result = yellowlightThread.getValue() * yellowdarkThread.getValue();
        System.out.println("risultato yellow: "+result);
    }

}
