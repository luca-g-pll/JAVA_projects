package yellow;



public class YellowlightThread extends Thread implements Runnable{
    private double a;
    private double b;
    private double c;
    private double result;
    
    public YellowlightThread(double a, double b, double c) 
    {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public void run() {
        result = (3*this.a+5)/(this.b-this.c);
        System.out.println("risultato lightyellow: "+result);

    }
    
    public double getValue() {
        return this.result;
    }
}
