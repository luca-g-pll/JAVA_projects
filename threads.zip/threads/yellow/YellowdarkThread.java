package yellow;




public class YellowdarkThread extends Thread implements Runnable
{
    private double a;
    private double b;
    private double c;
    private double result;
    
    public YellowdarkThread(double a, double b, double c) 
    {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public void run() {
        result = (3*this.a+5*this.c);
        System.out.println("risultato darkyellow: "+result);
    }
    
    public double getValue() {
        return this.result;
    }
}
