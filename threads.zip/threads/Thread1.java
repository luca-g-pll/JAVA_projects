import green.GreenThread;
import yellow.YellowThread;

public class Thread1 extends Thread implements Runnable{
    private double a;
    private double b;
    private double c;
    private double result;

    public Thread1(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public double getResult() {
        return this.result;
    }

    @Override
    public void run() {
        YellowThread yellowThread = new YellowThread(this.a, this.b, this.c);
        GreenThread greenThread = new GreenThread(this.a, this.b, this.c);
        yellowThread.run();
        greenThread.run();
        try {
            yellowThread.join();
            greenThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        result = yellowThread.getResult() + greenThread.getResult();
        System.out.println(result);
    }
}