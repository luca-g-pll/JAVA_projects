
public class Main
{
    public static void main(String[] args) 
    {
        Thread t1 = new Thread(new Thread1(4, 5, 9));
        t1.run();
        Thread t2 = new Thread(new Thread1(60, 6, 7));
        t2.run();
    }
}
