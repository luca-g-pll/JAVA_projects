package green;


public class GreenThread extends Thread implements Runnable
{
    private double a;
    private double b;
    private double c;
    private double result;

    public GreenThread(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public double getResult() {
        return this.result;
    }

    @Override
    public void run() {
        GreenlightThread greenlightThread = new GreenlightThread(this.a, this.b, this.c);
        GreendarkThread greendarkThread = new GreendarkThread(this.a, this.b, this.c);
        greenlightThread.start();
        greendarkThread.start();
        try {
            greenlightThread.join();
            greendarkThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        result = greenlightThread.getValue() / greendarkThread.getValue();
        System.out.println("risultato green: "+result);
    }
}
