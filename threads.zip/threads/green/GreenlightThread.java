package green;


public class GreenlightThread extends Thread implements Runnable
{
    private double a;
    private double b;
    private double c;
    private double result;
    
    public GreenlightThread(double a, double b, double c) 
    {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public void run() {
        result = (7-(this.a/this.b)+22);
        System.out.println("risultato lightgreen: "+result);

    }
    public double getValue() 
    {
        return this.result;
    }
}