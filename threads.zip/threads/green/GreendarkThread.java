package green;


public class GreendarkThread extends Thread implements Runnable
{
    private double a;
    private double b;
    private double c;
    private double result;
    
    public GreendarkThread(double a, double b, double c) 
    {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public void run() {
        result = (this.c+this.b+this.a);
        System.out.println("risultato darkgreen: "+result);

    }
    public double getValue() {
        return this.result;
    }
}