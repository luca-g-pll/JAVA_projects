
public class Application implements ICommandConsumer {

    SenderProtocol senderProtocol;

    public Application(SenderProtocol  sender ){

        senderProtocol=sender;
    }

    //implementazine dei diversi comandi da richiamare
    @Override
    public void maiuscolo(String message) {

        senderProtocol.buildMessage("maiuscolo",message.toUpperCase());
    }

    @Override
    public void minuscolo(String message) {

        senderProtocol.buildMessage("minuscolo",message.toLowerCase());
    }

    @Override
    public void inversione(String message) {
        senderProtocol.buildMessage("inversione",new StringBuilder(message).reverse().toString());
    }//istanza anonima, istanziata ma non memorizzata

    @Override
    public void eliminaSpazi(String message) {
        senderProtocol.buildMessage("eliminaSpazi",message.replaceAll(" ",""));
    }

    @Override
    public void eliminaVocali(String message) {
        senderProtocol.buildMessage("eliminaSpazi",message.replaceAll("[aeiouAEIOU]",""));
    }//espressione regolare

    @Override
    public void eliminaConsonanti(String message) {
    //replaceAll rimpiazzerà tutti i char inserit nella prima parte, con il char/string inseriti nella seconda parte
        senderProtocol.buildMessage("eliminaSpazi",
                message.replaceAll("[BCDFGHJKLMNPQRSTVWXYZbcdfghjklmnpqrstvwxyz]",""));
    }

    @Override
    public void close() {
        senderProtocol.close();
    }


}
