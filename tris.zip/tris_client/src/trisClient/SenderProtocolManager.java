package trisClient;
/**
 *
 *
 *
 */
import io.Sender;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class SenderProtocolManager {
    private final Sender sender;


    public SenderProtocolManager(Sender sender){
        this.sender = sender;
    }



    void sendLogin(String u) {
        sender.send("login#" + u);
    }
    void sendLogout() {
        sender.send("logout");
    }

    void sendRequestGame(String u){
        sender.send("invite#"+u);
    }
    void sendReplyGame(String u, String reply){
        sender.send("reply#"+u+"!"+reply);
    }

    void sendMove(String username, String info,String info2){
        sender.send("move#"+username+"!"+info+"!"+info2);
    }

    void sendEndGame(String username, String info){
        sender.send("endGame#"+username+"!"+info);
    }

    public void sendClose(){ sender.close(); }

  //  public void sendError(int value){         sender.send("\nError#"+errorMessages.get(value)+"\n");     }



}
