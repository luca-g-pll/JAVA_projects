package trisClient;
/**
*
*
*
 */

import io.IMessageConsumer;
import io.Reader;
import io.Sender;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;


public class Main {
    public static void main(String[] args) throws IOException {


        Socket s = new Socket("localhost",60000);

        PrintWriter out = new PrintWriter(s.getOutputStream());
        BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));

        Sender sender = new Sender(out);
        SenderProtocolManager senderProtocol = new SenderProtocolManager(sender);

        IApplicationObserver appView = new View(senderProtocol);

        ICommandConsumer app = new Application(appView);
        IMessageConsumer receiver = new ReceiverProtocolManager(app);

        Reader reader = new Reader(in, "quit");
        reader.setConsumer(receiver);
    }
}