package trisClient;
/**
 *
 *
 *
 */
import io.IMessageConsumer;
import java.util.ArrayList;

public class ReceiverProtocolManager implements IMessageConsumer {

    ICommandConsumer consumer;
    ArrayList<String> users;

    public ReceiverProtocolManager(ICommandConsumer consumer) {
        this.consumer = consumer;
        this.users = new ArrayList<String>();
    }

    @Override
    public void consumeMessage(String s) {

        String[] cmd = s.split("#");
        String command = cmd[0];
        String[] parametri = null;

        if (cmd.length > 1) {
            parametri = cmd[1].split("!");
        }
        System.out.println(s);
        //System.out.println(command);
        switch (command) {

            //login del giocatore sulla hashmap -1
            case "login", "loginFailed" -> {
                    consumer.login(parametri[0]);
            }

            //ricezione di un invito da # utente
            case "invite" -> {
                    consumer.requestGameInvite(parametri[0]);
            }

            //ricevo risposta da mio invito
            case "reply" -> {
                assert parametri != null;
                consumer.replyGameInvite(parametri[0], parametri[1]);
            }

            case "startGame" -> {//arriva solo se ha accettato l'avversario
                    consumer.startGame(parametri[0]);
            }

            //inviare la mossa fatta al giocatore avversario
            case "move" -> {
                    consumer.userMove(parametri[0], parametri[1],parametri[2]);
            }

            //inviare al giocatore aversario gli esiti della partita
            case "endGame" -> {
                    consumer.endgame(parametri[0], parametri[1]);
            }

            // ottiene la lista -2
            case "userList" -> {

                    for(int i = 0 ;i< parametri.length; i ++ ) {
                        this.users.add(parametri[i]);
                    }
                    consumer.userList(this.users);
            }

            //logout di un giocatore esterno
            case "logout" -> {
                    consumer.removeUser(parametri[0]);
            }

            case "Error" -> {
                System.out.println(s);//al momento stampo a video l'errore che arriva
            }

            //non conosce il comando
            default -> {
                consumer.error(1);
            }
        }
    }

    //public void close() {  consumer.logout(); }

}
