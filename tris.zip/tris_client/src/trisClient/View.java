package trisClient;
/**
 * Deve poi implementare la IApplicationObserver per modificarsi
 * e bisogna passargli il sender manager per inviare le sue azioni
 * @author INFODOC-2
 */
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.*;

//aggiungere altre finestre in base a come funzionerà il client e la sau interfaccia --> sfruttando i metodi di :
//IApplicationObserver
//passare un instanza di SenderProtocol Manager nel costruttore, in modo da inviare le azioni al server
public class View extends JFrame implements IApplicationObserver{
    private JFrame login = new JFrame();

    int mosseRimaste = 9;

    private  int startChange = 0;
    private int numerTurnChange = 1;


    //utile per fare il logout
    private ICommandConsumer app;

    private String userVs = new String();

    private String sign = null;
    public boolean myTurn = false;




    //matrice per griglia di gioco
    //button : toggle --> due stati slezionato o no e returnano un boolena
    private JToggleButton[][] field;
    //modello e corrispettiva lista per visualizzazione utenti connessi
    private DefaultListModel<String> modelUsers;
    private JList<String> users;
    //modello e corrispetiva lista per visualizzare i messaggi di sistema
    private DefaultListModel<String> modelMessages;
    private JList<String> messages;

    //dichiarazione bottoni :
    private JButton connect;
    private JButton disconnect;

    private final SenderProtocolManager sender;

    //costruttore :
    public View(SenderProtocolManager sender){

        //this.boxReply();

        this.sender = sender;

        //metodo creazione campo di gioco
        this.createField();
        //metodo creazione liste e modelli
        this.instanceGui();
        //metodo creazione bottoni conn - disconn
        this.createButtonConn();

        //fram per fare il login
        this.doLogin();


        //metodo per le impostazioni del pannello principale
        this.settingPanel();

    }





    //metodi per la creazione della interfaccia grafica principale :
//---------------------------------------------------------------------------------------------------------------------
//metodo per l'instanziamento del campo di gioco
    private void createField(){
        //campo 3x3 --> matrice di bottoni 'field' ,
        field = new JToggleButton[3][3];
        //aggiuen il campo di gioco al al pannello centrare
        JPanel center=new JPanel(new GridLayout(3,3,2,2));
        //
        for (int x = 0; x < field.length; x++) {
            for (int y = 0; y < field.length; y++) {
                //pulsante disabilitato fuori dalla partita
                field[x][y]=new JToggleButton("");
                field[x][y].setEnabled(false);
                //comando d'azione con stringa che indica posizione bottone indici x - y
                field[x][y].setActionCommand(x+"?"+y);//returna la strina assegnata al bottono quando cliccato
                field[x][y].addActionListener( new ActionListener() {

                    public void actionPerformed(ActionEvent e) {
                        //passare un boolean per il turno ________________________________________________________________


                      //  JButton clickedButton = (JButton) e.getSource();
                      //  String actionCommand = clickedButton.getActionCommand();
                        String command = e.getActionCommand();//restituisce la stringa


                        returnValueField(command);//ottengo il valore del bottone



                        //controllo ogni volta che schiaccio un bottone che sia vinta o patta

                        //cambio il segno di un bottone quando è cliccato e lo disabilito

                    }
                });

                //aggiunto pulsante al pannello principale
                center.add(field[x][y]);
            }
        }
        //aggiunta la griglia di gioco al pannello
        add(center);
    }

//istanziamneto modelli e liste
    private void instanceGui(){
        //creazione di liste e rispettivi modelli :
        //aggiunta lista 'users'--> posizionata ad est del pannello
        modelUsers=new DefaultListModel<>();
        users=new JList(modelUsers);
        users.setBorder(BorderFactory.createTitledBorder("Users online"));
        add(new JScrollPane(users),BorderLayout.EAST);

        //aggiunta lista 'messages'--> posizionata a sud del pannello
        modelMessages=new DefaultListModel<>();
        messages=new JList(modelMessages);
        messages.setBorder(BorderFactory.createTitledBorder("Messages of log"));
        add(new JScrollPane(messages),BorderLayout.SOUTH);
    }

//creazione dei bottoni di connessione al server :
    private void  createButtonConn(){
        //inizializzati i due bottoni per la connessione e quindi login del giocatore
        //e bottone per il logout quindi il quit dal server e la rimozione del suo nome dalle liste dei giocatori
        connect=new JButton ("Send Request");
        disconnect=new JButton("Logout");

        //azione per bottone di connect --> send request to user
        connect.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String u = users.getSelectedValue();
                //mando richiesta al client con cui voglio giocare
                sender.sendRequestGame(u);
            }
        });
        //azione per bottone di disconnect --> logout
        disconnect.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sender.sendLogout();
                modelUsers.clear();
                modelMessages.clear();
                modelMessages.addElement("ti sei disconnesso");
                doLogin();
            }
        });

//aggiunta dei bottoni di disconnessione e connessione al pannello, nella parte 'nord' dello stesso
        //disconnect.setEnabled(false);
        JPanel north=new JPanel();
        north.add(connect);
        north.add(disconnect);
        add(north,BorderLayout.NORTH);
    }

//Impostazioni del pannello principale : chiusura e sua visualizzazione e spostamento/posizione
    private void settingPanel(){
        //bottone di chiusura del bannello
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                //mandare anche al giocatore avversario se sono in partita che ho abbandonato
                sender.sendLogout();
            }
        });

        //impostazioni del pannello :
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }
//---------------------------------------------------------------------------------------------------------------------


    //metodi per joinare e leftare dalla lista del client :
    //join
    @Override
    public void addUser(String username) {
        if(!modelUsers.contains(username)) {
            modelUsers.addElement(username);
            modelMessages.addElement("Join : " + username);
        }
    }
    //left
    @Override
    public void removeUser(String username) {
        modelUsers.removeElement(username);
        modelMessages.addElement("Left : "+username);
    }

    @Override
    public void returnValueField(String actCommand) {
        // Esempio di come estrarre i valori x e y dall'actionCommand
        String[] coordinates = actCommand.split("\\?");
        //cambio di segno
        field[Integer.parseInt(coordinates[0])][Integer.parseInt(coordinates[1])].setText(this.sign);

        sender.sendMove(this.userVs,coordinates[0],coordinates[1]);


        notMyTurn();
        //mandare come move
    }

    //operazioni da fare ad inizio partita
    @Override
    public void startGame(String u, String sign) { //lo uso per inzializzare il campo o per inzializzare i nomi ad inizio partita
        this.userVs = u;
        this.sign = sign;
       //abilito i bottoni
        if(sign.equals("X") || myTurn) {
            for (int x = 0; x < field.length; x++) {
                for (int y = 0; y < field.length; y++) {
                    //pulsante disabilitato fuori dalla partita --> se toggleButton.isSelected() = bool
                    if (!sign.equals("")) {
//                    System.out.println(sign);
                        field[x][y].setEnabled(true);
                    }
                }
            }
        }
        //diabilito il bottone per nopn poter far rihcieste a qualcuno se sto giocando
        connect.setEnabled(false);
        //dopo aver inizializzato il tutto gioco effettivamente
    }

    @Override
    public void setSign(String s){
        this.sign = s;
    }


    @Override
    public void playTris(String sign) {

                for (int x = 0; x < field.length; x++) {
                    for (int y = 0; y < field.length; y++) {
                        if (!field[x][y].getText().equals("X") && !field[x][y].getText().equals("O")) {
                            field[x][y].setEnabled(true);
                        }
                    }
                }
    }

    @Override
    public void controlMoveGame(int x, int y) {
        if(mosseRimaste>4) {

            this.myTurn();

            String s = "X";
            if (this.sign.equals("X")) {
                s = "O";
            }
            field[x][y].setText(s);

            playTris(this.sign);

        }else{
            if(controlloWinCampo()){
                sender.sendEndGame(this.userVs,"win");
            }else{
                this.myTurn();

                String s = "X";
                if (this.sign.equals("X")) {
                    s = "O";
                }
                field[x][y].setText(s);

                playTris(this.sign);
            }
            //rifai il sopra

        }
    }

    //metodo che mostra il panel per gli errori di login
    @Override
    public void showErrorLogin(String s) {
    JOptionPane.showMessageDialog(
                    /* parentComponent */ null,
                    /* message */ s,
                    /* title */ "Error on Login - repeat please",
                    /* messageType */ JOptionPane.ERROR_MESSAGE
            );
     this.doLogin();
    }
    //metodo che mostra il panel per il login
    @Override
    public void doLogin() {
            String user=JOptionPane.showInputDialog(View.this, "Inserire nome utente : ");
            loginUser(user);
    }
    private void loginUser(String username){
        sender.sendLogin(username);
    }

    @Override
    public void boxReplyToRequest(String u,boolean on) {
        // Show the Yes-No dialog box
        if(!on){
            int result = JOptionPane.showConfirmDialog(
                    /* parentComponent */ null,
                    /* message */ "Accetti la partita ?",
                    /* title */ "Reply to request from :" + u,
                    /* optionType */ JOptionPane.YES_NO_OPTION
            );
            // Analyze the user's choice
            if (result == JOptionPane.YES_OPTION) {
                sender.sendReplyGame(u, "yes");
                this.userVs = u;
            } else if (result == JOptionPane.NO_OPTION) {
                //System.out.println("User clicked No");
                sender.sendReplyGame(u, "no");
            } else if (result == JOptionPane.CLOSED_OPTION) {
                sender.sendReplyGame(u, "no");
            }
        }else{
            sender.sendReplyGame(u, "no - sto giocando");
        }
    }

    public void myTurn(){
        this.myTurn = true;
    }
    public void notMyTurn(){
        this.myTurn = false;

        for (int x = 0; x < field.length; x++) {
            for (int y = 0; y < field.length; y++) {
                    field[x][y].setEnabled(false);
            }
        }
    }


//controllo del campo di gioco
    private boolean controlloWinCampo(){
        boolean win = false;
        String[] segni = new String[]{"X","O"};

//righe
        for(int s = 0; s < 2; s++){
            int i = 0;
            for (int y = 0; y < 3; y++){
                if(field[i][y].getText().equals(segni[s]) && field[i+1][y].getText().equals(segni[s]) && field[i+2][y].getText().equals(segni[s]) )
                    win = true;
            }
        }
//colonne
        for(int s = 0; s < 2; s++){
            int i = 0;
            for (int y = 0; y < 3; y++){
                if(field[y][i].getText().equals(segni[s]) && field[y][i+1].getText().equals(segni[s]) && field[y][i+2].getText().equals(segni[s]) )
                    win = true;
            }
        }
//diagonali dx
        for(int s = 0; s < 2; s++) {
            int i = 0;
            int y = 0;
            if (field[y][i].getText().equals(segni[s]) && field[y + 1][i + 1].getText().equals(segni[s]) && field[y + 2][i + 2].getText().equals(segni[s]))
                win = true;
        }
//diagonale sx
        for(int s = 0; s < 2; s++) {
            int i = 0;
            int y = 0;
            if (field[y+2][i].getText().equals(segni[s]) && field[y + 1][i + 1].getText().equals(segni[s]) && field[y][i + 2].getText().equals(segni[s]))
                win = true;
        }

        return win;
    }

}
