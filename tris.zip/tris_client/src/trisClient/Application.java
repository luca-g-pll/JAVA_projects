package trisClient;
/**
 *
 *
 *
 */
//shift+f6 su un nome me lo cambia su una intera classe
import java.util.ArrayList;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class Application implements ICommandConsumer{

    private int mosse = 9; //mosse massime che può fare un giocatore

    private boolean playing = false;
    //private final SenderProtocolManager sender;
    private IApplicationObserver view;
    //private final Map<String, SenderProtocolManager> hashMap;

    private String usernameVs = new String();

    public Application(IApplicationObserver view){
        this.view = view;
    }


    @Override
    public void login(String username) {
        if (username.equals("username exists") || username.equals("you are logged")) {
            view.showErrorLogin(username);
        }
        //altrimenti vado direttamente alla frame principale
    }



    @Override
    public void logout() {
        //hashMap.remove(this.username);
       // Set<String> keys = hashMap.keySet();
       // for (String key : keys) {
          //  hashMap.get(key).sendLogout(this.username);
       // }
        //oltre al logout chiudo la connessione con il giocatore
        //sender.sendClose();
    }


    public void userList(ArrayList<String> users){
            for(String user : users){
                view.addUser(user);
            }
    }

    public void removeUser(String user){
        view.removeUser(user);
    }

    @Override
    public void requestGameInvite(String userName) {

            view.boxReplyToRequest(userName,playing);
        //hashMap.get(userName).sendRequestGame(this.username);
    }

    //con X inizio 1 se ho - O inizio 2
    @Override
    public void replyGameInvite(String userName, String reply) {        //elaboro risposta
        if(!playing && reply.equals("yes")) {
                this.playing = true;
                this.usernameVs = userName;
                //il giocatore sarà definito come online
                //inizio la partita e devo aspettare che arrivi lo start game dal serverà
                //che mi dice chi inizia
        }
    }

    @Override
    public void startGame(String info) {

        //il giocatore è in partita, noon dovrebbe ricere altre richieste
        if(info.equals("X")) {//inizia per primo
            view.startGame(this.usernameVs, info);
            view.playTris(info);
            view.myTurn();
        }
        else{
            view.notMyTurn();
            view.setSign(info);
        }

    }

    @Override
    public void setUsernameVs(String u){
        this.usernameVs = u;
    }

    @Override
    public void userMove(String userName, String info,String info2) {
        view.controlMoveGame(Integer.parseInt(info),Integer.parseInt(info2));

    }

    @Override
    public void endgame(String userName,String info) {
        playing = true; //torno disponibile per giocare se

    }

    @Override
    public void error(int code) {
        //sender.sendError(code);
    }

}
