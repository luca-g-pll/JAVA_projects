package trisClient;
/**
 *  metodi necessari all'aggiornamento dellìinterfaccia utente 'view'
 *
 *
 */
public interface IApplicationObserver {
    void addUser(String username);
    void showErrorLogin(String s);
    void doLogin();

    void boxReplyToRequest(String u,boolean on);

    void removeUser(String username);
    void returnValueField(String actCommand);

    void startGame(String u,String sign);
    void playTris(String sign);

    void controlMoveGame(int x, int y);

    void myTurn();
    void setSign(String s);

    void notMyTurn();
}

