package trisClient;

import java.util.ArrayList;

/**
 *
 *
 *
 */

public interface ICommandConsumer {

void login(String username);

void logout();

void requestGameInvite(String userName);
void replyGameInvite(String userName,String reply);

void startGame(String info);
void userMove(String userName,String info,String info2);

void endgame(String userName,String info);

void error(int code);

void userList(ArrayList<String> users);

void removeUser(String user);

void setUsernameVs(String u);
}
