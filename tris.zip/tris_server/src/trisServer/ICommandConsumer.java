package trisServer;
/**
 *
 *
 *
 */

public interface ICommandConsumer {

void login(String username);

void logout();

void requestGameInvite(String userName);
void replyGameInvite(String userName,String reply);

void userMove(String userName,String info,String info2);

void endgame(String userName,String info);

void error(int code);

}
