package trisServer;
/**
 *
 *
 *
 */

import java.util.Map;
import java.util.Random;
import java.util.Set;

public class Application implements ICommandConsumer{
    private final SenderProtocolManager sender;
    private final Map<String, SenderProtocolManager> hashMap;
    private String username;

    public Application(Map<String, SenderProtocolManager> map, SenderProtocolManager sender){
        this.hashMap = map;
        this.sender = sender;
    }


    @Override
    public void login(String username) {
        if (!hashMap.containsKey(username)) {
            if (this.username == null) {
                this.username = username;
                hashMap.put(username, this.sender);
                //aggiunge a tutti i client la lista aggiornata
                Set<String> keys = hashMap.keySet();
                //dice a tutti a tutti gli utenti collegati che qualcuno di nuovo si è collegati
                for (String key : keys) {
                    hashMap.get(key).sendUserList(keys);
                }
                sender.sendLogin(username);
            } else {
                sender.sendLoginFailed(2);
            }
        } else {
            sender.sendLoginFailed(1);
        }
    }

    @Override
    public void logout() {
        hashMap.remove(this.username);
        Set<String> keys = hashMap.keySet();
        for (String key : keys) {
            hashMap.get(key).sendLogout(this.username);
        }
        this.username = null;
        //oltre al logout chiudo la connessione con il giocatore
        //sender.sendClose(); --> levo perchè il canale di comunicazione col clietn in questione è chiuso e allora darebbe errore di comunicazione
    }

    //per richiesta di invito a partita
    @Override
    public void requestGameInvite(String userName) {
        hashMap.get(userName).sendRequestGame(this.username);
    }

    //risposta di accettazione alla partita
    @Override
    public void replyGameInvite(String userName, String reply) {
        if(reply.equals("yes")) {

            //accetta X inizia prima e O inizia secondo
            Random random = new Random();
            int randomNumber = random.nextInt(2) + 1;

            //invio della reply viene scritta due volte, perche se accetta allora deve arrivare prima reply poi start
            hashMap.get(userName).sendReplyGame(this.username,reply);
            //mandati ad entrambi i giocatori il rispettivo segno :
            this.startInfoGame(userName,randomNumber);
        }else {
            //caso non abbia accettato
            hashMap.get(userName).sendReplyGame(this.username,reply);
        }
    }

    //tramite il numero random decido quale sarà ad iniziare
    private void startInfoGame(String userName, int n){
        if(n == 1){//se esce 1 inizia chi ha iniviato
            hashMap.get(this.username).sendStartGame("O");
            hashMap.get(userName).sendStartGame("X");
        }else{//se esce 2 inizia chi ha accettato
            hashMap.get(this.username).sendStartGame("X");
            hashMap.get(userName).sendStartGame("O");
        }
    }

    @Override
    public void userMove(String userName, String info,String info2) {
        System.out.println(userName);
        hashMap.get(userName).sendMove(this.username,info,info2);

    }

    @Override
    public void endgame(String userName,String info){
        hashMap.get(userName).sendEndGame(this.username,info);
    }

    @Override
    public void error(int code) {
        sender.sendError(code);
    }
}
