package trisServer;
/**
 * Pillitu Luca
 * Main - esecuzione codice
 *
 */

import io.IMessageConsumer;
import io.Reader;
import io.Sender;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;


public class Main {
    public static void main(String[] args) throws IOException {
        ServerSocket ss = new ServerSocket(60000);

        Map<String, SenderProtocolManager> hashMap = new HashMap<>();

        while (true) {
            Socket s = ss.accept();

            PrintWriter out = new PrintWriter(s.getOutputStream());
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));

            Sender sender = new Sender(out);
            SenderProtocolManager senderProtocol = new SenderProtocolManager(sender);

            ICommandConsumer app = new Application(hashMap,senderProtocol);
            IMessageConsumer receiver = new ReceiverProtocolManager(app);

            Reader reader = new Reader(in, "quit");
            reader.setConsumer(receiver);

        }
    }
}