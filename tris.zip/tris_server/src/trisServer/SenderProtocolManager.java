package trisServer;
/**
 *
 *
 *
 */
import io.Sender;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class SenderProtocolManager {
    private final Sender sender;
    private final Map<Integer,String> errorMessages;
    private final Map<Integer,String> loginResult;

//costruttore
    public SenderProtocolManager(Sender sender){
        this.sender = sender;

        errorMessages = new HashMap<>();
        errorMessages.put(1,"client - unknown command");
        errorMessages.put(2,"client - missing parameters");

        loginResult = new HashMap<>();
        loginResult.put(1,"username exists");
        loginResult.put(2,"you are logged");
    }
//metodi per invio
    void sendLogin(String u) {
        sender.send("login#" + u);
    }
    void sendLoginFailed(int code) {
        sender.send("loginFailed#" + loginResult.get(code));
    }

    //per dire ai client collegati che uno se ne va
    void sendLogout(String username) {
        sender.send("logout#" + username);
    }
    void sendUserList(Set<String> users) {
        //userList lo gestirà poi il client
        String message = "userList#";
        for (String user : users) {
            message += user + "!";
        }
        message = message.substring(0, message.length() - 1);
        sender.send(message);
    }

    //
    //manda la richiesta di gioco
    void sendRequestGame(String u){
        sender.send("invite#"+u);
    }

    //manda la risposta alla richiesta di gioco

    void sendReplyGame(String u, String reply){
        sender.send("reply#"+u+"!"+reply);
    }

    void sendStartGame(String segno){
        sender.send("startGame#"+segno);
    }

    void sendMove(String username, String info,String info2){
        sender.send("move#"+username+"!"+info+"!"+info2);
    }

    void sendEndGame(String username, String info){
        sender.send("endGame#"+username+"!"+info);
    }

    //public void sendClose(){ sender.close(); }
    public void sendError(int value){
        sender.send("\nError#"+errorMessages.get(value)+"\n");
    }



}
