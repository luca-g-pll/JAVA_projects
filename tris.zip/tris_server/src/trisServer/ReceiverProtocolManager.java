package trisServer;
/**
 *
 *
 *
 */
import io.IMessageConsumer;
public class ReceiverProtocolManager implements IMessageConsumer {
    ICommandConsumer consumer;

    public ReceiverProtocolManager(ICommandConsumer consumer) {
        this.consumer = consumer;
    }

    @Override
    public void consumeMessage(String s) {

        String[] cmd = s.split("#");
        String command = cmd[0];
        String[] parametri = null;

        if (cmd.length > 1) {
            parametri = cmd[1].split("!");
        }

        switch (command) {

            //login del giocatore sulla hashmap
            case "login" -> {
                    consumer.login(parametri[0]);
            }

            //invitare un giocatore per una partita
            case "invite" -> {
                    consumer.requestGameInvite(parametri[0]);
            }

            //mandare la risposta ad un giocatore per la partita fatta
            case "reply" -> {
                    consumer.replyGameInvite(parametri[0], parametri[1]);
            }

            //inviare la mossa fatta al giocatore avversario
            case "move" -> {
                    consumer.userMove(parametri[0], parametri[1],parametri[2]);
            }

            //inviare al giocatore aversario gli esiti della partita
            case "endGame" -> {
                    consumer.endgame(parametri[0], parametri[1]);
            }

            //logout del giocatore
            case "logout" -> {
                this.close();
            }

            //non conosce il comando
            default -> {
                consumer.error(1);
            }
        }
    }

    public void close() {  consumer.logout(); }

}
