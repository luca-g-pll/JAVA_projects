import io.Sender;

import java.util.HashMap;
import java.util.Map;

public class SenderProtocolManager implements ISenderProtocolManager{
    private Sender sender;
    Map<Integer, String> errori;
    Map<Integer, String> status;

    SenderProtocolManager(Sender s){
        this.sender = s;
        this.errori = new HashMap<>();
        this.status = new HashMap<>();
        errori.put(101, "MissingParameter");
        errori.put(102, "LoginAlreadyDone");
        errori.put(103, "UnknownAccount");
        errori.put(104, "UnknownCommand");
        errori.put(105, "UserAlreadyConnected");

        status.put(201, "LoginOK");
        status.put(405, "UnknownUsername|UnknownPassword");
    }

    @Override
    public void addUser(String username) {
        sender.send("Login*"+username);
    }

    @Override
    public void removeUser(String username) {
        sender.send("Logout*"+username);
    }

    @Override
    public void action(String data, String opponent, String letter) {
        sender.send("Azione*"+opponent+"$"+data+"&"+letter);
    }

    @Override
    public void request(String username) {
        sender.send("Richiesta*"+username);
    }

    @Override
    public void response(String username, String status) {
        sender.send("Response*"+username+"$"+status);
    }

    @Override
    public void letter(String username, String letter) {
        sender.send("Letter*"+username + "$"+letter);
    }

    @Override
    public void sendWinner(String opponent, String letter) {
        sender.send("Winner*"+opponent+"$"+letter);
    }

    @Override
    public void isInGame(String opponent) {
        sender.send("InGame*"+opponent);
    }

    @Override
    public void sendInGameStatus(boolean status) {
        sender.send("InGameStatus*"+status);
    }

    @Override
    public void errore(int code) {
        sender.send("Errore*"+errori.get(code));
    }

    @Override
    public void close() {
        sender.close();
    }
}
