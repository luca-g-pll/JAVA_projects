public interface IApplicationObserver {
    void addUser(String username);
    void deleteUser(String username);
    boolean isUserInGame(String opponent);
    void ingamestatus(String opponent);
    void action(String action, String opponent, String letter);
    void obtainLetter();
    void setLetter(String letter);
    void refusedGame(String u);
    void request(String username);
    void initGame();
    boolean updateField(String infos, String letter);
    void resetField();
    void checkWinCondition(int i, int j);
    void checkWinner();
    void winner(String winner);
    void updateUsers(String infos);
    void updateLogs(String message);
    void error(String error);
}
