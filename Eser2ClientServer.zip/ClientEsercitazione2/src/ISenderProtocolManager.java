public interface ISenderProtocolManager {
    void addUser(String username);
    void removeUser(String username);
    void action(String action, String opponent, String letter);
    void request(String username);
    void response(String username, String status);
    void letter(String username, String letter);
    void sendWinner(String opponent, String letter);
    void isInGame(String opponent);
    void sendInGameStatus(boolean status);
    void errore(int code);
    void close();


}
