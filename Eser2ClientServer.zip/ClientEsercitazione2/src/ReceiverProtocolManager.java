import io.IMessageConsumer;

public class ReceiverProtocolManager implements IMessageConsumer {
    ICommandConsumer c;

    ReceiverProtocolManager(ICommandConsumer c) {
        this.c = c;
    }

    @Override
    public void consumeMessage(String s) {
        System.out.println(s);
        String[] message = s.split("\\*");
        switch (message[0].toLowerCase()) {
            case "login" -> {
                c.login(message[1]);
            }
            case "logout" -> {
                c.logout(message[1]);
            }
            case "letter" -> {
                c.setLetter(message[1]);
            }
            case "azione" -> {
                c.action(message[1]);
            }
            case "richiesta" -> {
                c.request(message[1]);
            }
            case "connectedusers" -> {
                try {
                    c.connectedUsers(message[1]);
                }catch (ArrayIndexOutOfBoundsException ignored){}
            }
            case "response" -> {
                c.response(message[1]);
            }
            case "winner" -> {
                c.winner(message[1]);
            }
            case "ingamestatus" -> {
                c.ingamestatus(message[1]);
            }
            case "errore" -> {
                c.error(message[1]);
            }
            default -> {}
        }

    }
}
