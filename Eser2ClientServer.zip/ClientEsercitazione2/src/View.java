/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Objects;
import java.util.Random;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class View extends JFrame implements ActionListener, IApplicationObserver{
    ISenderProtocolManager sp;
    private JButton[][] field;
    private JPanel center=new JPanel(new GridLayout(3,3,2,2));
    private DefaultListModel<String> modelUsers;
    private JList<String> users;
    private DefaultListModel<String> modelMessages;
    private JList<String> messages;
    private JButton connect;
    private JButton disconnect;
    private JButton request;
    private String opponent;
    private String letter;
    private String user;
    private int c;
    private int c2;
    private int countX = 0;
    private int countO = 0;
    private boolean inGame = false;
    
    public View(ISenderProtocolManager sp){
        this.sp = sp;
        c=0;
        field=new JButton[3][3];
        add(center);
        resetField();
        modelUsers=new DefaultListModel<>();
        users=new JList(modelUsers);
        users.setBorder(BorderFactory.createTitledBorder("Users"));
        add(new JScrollPane(users),BorderLayout.EAST);
        modelMessages=new DefaultListModel<>();
        messages=new JList(modelMessages);
        messages.setBorder(BorderFactory.createTitledBorder("Messages"));
        add(new JScrollPane(messages),BorderLayout.SOUTH);
        connect=new JButton ("Connect");
        connect.setEnabled(true);
        disconnect=new JButton("Disconnect");
        disconnect.setEnabled(false);
        request=new JButton("Request");
        request.setEnabled(false);

        connect.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(c==0){
                    user=JOptionPane.showInputDialog(View.this, "Inserire utente");
                    addUser(user); //aggiunta utente
                    connect.setEnabled(false);
                    disconnect.setEnabled(true);
                    request.setEnabled(true);
                    c++;
                }else{
                    JOptionPane.showMessageDialog(View.this, "Ti sei già connesso!");
                }
            }
        });
        disconnect.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //JOptionPane.showMessageDialog(View.this, user);
                connect.setEnabled(true);
                disconnect.setEnabled(false);
                request.setEnabled(false);
                deleteUser(user);
                c=0;
                //disconnessione utente
            }
        });

        request.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                opponent=users.getSelectedValue();
                sp.isInGame(opponent);
                try{
                    if(!opponent.equals(user) && !isUserInGame(opponent)) {
                        sp.request(opponent);
                        request.setEnabled(false);
                        JOptionPane.showMessageDialog(View.this, "Richiesta inviata!");
                    }else if(opponent.equals(user)){
                        JOptionPane.showMessageDialog(View.this, "Non puoi inviare una richiesta a te stesso!");
                    }else{
                        JOptionPane.showMessageDialog(View.this, "Il giocatore è attualmente impegnato in una partita!");
                    }
                }catch (NullPointerException npe){
                    JOptionPane.showMessageDialog(View.this, "Devi selezionare un giocatore dalla colonna a sinistra!");
                }

            }
        });
        JPanel north=new JPanel();
        north.add(connect);
        north.add(disconnect);
        north.add(request);
        add(north,BorderLayout.NORTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                //disconnettersi prima della chiusura
                deleteUser(user);
                sp.close();
            }
        });
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    @Override
    public boolean isUserInGame(String value){
        return value.equals("true");
    }

    @Override
    public void ingamestatus(String opponent) {
        sp.sendInGameStatus(inGame);
    }

    @Override
    public void resetField(){
        remove(center);
        opponent = "";
        letter = "";
        center = new JPanel(new GridLayout(3,3,2,2));
        for (int i = 0; i < field.length; i++) {
            for (int j = 0; j < field.length; j++) {
                field[i][j]=new JButton("In attesa...");
                field[i][j].setEnabled(false);
                field[i][j].setActionCommand(i+"#"+j);
                field[i][j].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if(updateField(e.getActionCommand(), letter)){
                            action(e.getActionCommand(), opponent, letter);
                            checkWinner();
                        }
                    }
                });
                center.add(field[i][j]);
            }
        }
        add(center);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    @Override
    public void checkWinner(){
        // 3 in una riga/colonna/diagonale
        // Controllo orizzontale
        for(int i = 0; i < 3; i++){
            for (int j = 0; j < 3; j++) {
                checkWinCondition(i, j);
            }
            countO = 0;
            countX = 0;
        }

        // Controllo verticale
        for (int j = 0; j < 3; j++) {
            for(int i = 0; i < 3; i++){
                checkWinCondition(i, j);
            }
            countO = 0;
            countX = 0;
        }

        // Controllo diagonale
        int counterI = 0;
        int counterJ = 0;

        for (int i = 0; i < 3; i++){
            checkWinCondition(counterI, counterJ);
            counterI++;
            counterJ++;
        }
        countX = 0;
        countO = 0;

        counterI = 2;
        counterJ = 0;
        for (int i = 0; i < 3; i++){
            checkWinCondition(counterI, counterJ);
            counterI--;
            counterJ++;
        }
    }

    @Override
    public void winner(String winner) {
        JOptionPane.showMessageDialog(this, "The winner is " + winner);
        request.setEnabled(true);
        resetField();
    }

    @Override
    public void checkWinCondition(int i, int j) {
        if(field[i][j].getText().equals("X")){
            countX++;
        }else if(field[i][j].getText().equals("O")){
            countO++;
        }

        if(countX == 3){
            //vince X
            sp.sendWinner(opponent, "X");
            request.setEnabled(true);
            resetField();
            pack();
        } else if (countO == 3) {
            //vince O
            sp.sendWinner(opponent,"O");
            request.setEnabled(true);
            resetField();
            pack();
        }
    }


    @Override
    public void actionPerformed(ActionEvent e) {}

    @Override
    public void addUser(String username) {
        if(c2 == 0){
            sp.addUser(username);
            c2++;
        }
    }

    @Override
    public void deleteUser(String username) {
        sp.removeUser(username);
        c2=0;
        modelUsers.removeElement(username);
    }

    @Override
    public void action(String action, String opponent, String letter) {
        //usare le i e j ottenute dall'action performed dell'altro player per aggiornare
        sp.action(action, opponent, letter);
    }

    @Override
    public void refusedGame(String u) {
        JOptionPane.showMessageDialog(View.this, u+" ha rifiutato la richiesta");
        opponent = null;
    }

    @Override
    public void request(String username) {
        int reply = JOptionPane.showConfirmDialog(null, "Richiesta di gioco da "+ username +", accetti?", "Request", JOptionPane.YES_NO_OPTION);
        if (reply == JOptionPane.YES_OPTION) {
            //YES
            sp.response(username, "YES");
            opponent = username;
            inGame = true;
            initGame();
        } else {
            sp.response(username, "NO");
            request.setEnabled(true);
        }
    }

    @Override
    public void obtainLetter(){
        //assegna le lettere (X, O)
        String[] letters = {"X", "O"};
        Random r = new Random();
        //sceglie la lettera in modo random
        letter = letters[r.nextInt(letters.length)];
        if(letter.equals("X")){
            sp.letter(opponent,"O");
        }else{
            sp.letter(opponent,"X");
        }
    }

    @Override
    public void setLetter(String letter) {
        this.letter = letter;
    }

    @Override
    public void initGame() {
        for (int i = 0; i < field.length; i++) {
            for (int j = 0; j < field.length; j++) {
                field[i][j].setText("            ");
                field[i][j].setEnabled(true);
                field[i][j].setActionCommand(i+"#"+j);
                field[i][j].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if(updateField(e.getActionCommand(), letter)){
                            action(e.getActionCommand(), opponent, letter);
                            checkWinner();
                        }
                    }
                });
            }
        }
    }

    @Override
    public boolean updateField(String action, String letter) {
        String[] coords = action.split("#");
        if(field[Integer.parseInt(coords[0])][Integer.parseInt(coords[1])].getText().equals("            ")){
            field[Integer.parseInt(coords[0])][Integer.parseInt(coords[1])].setText(letter);
            return true;
        }
        return false;
    }

    @Override
    public void updateUsers(String infos) {
        modelUsers.removeAllElements();
        String[] usersConnected = infos.split("\\$");
        for (String s : usersConnected) {
            modelUsers.addElement(s);
        }
    }

    @Override
    public void updateLogs(String message) {
        modelMessages.addElement(message);
    }

    @Override
    public void error(String error) {
        if(error.equals("UserAlreadyConnected")) {
            JOptionPane.showMessageDialog(View.this, "Errore! " + error);
            connect.setEnabled(true);
            disconnect.setEnabled(false);
        }
    }
}
