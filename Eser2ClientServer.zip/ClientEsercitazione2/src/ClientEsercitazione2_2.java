import io.IMessageConsumer;
import io.Reader;
import io.Sender;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ClientEsercitazione2_2 {
    public static void main(String[] args) throws IOException {
        Socket s=new Socket("127.0.0.1", 60000);
        PrintWriter out=new PrintWriter(s.getOutputStream());
        BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream()));
        Sender sender=new Sender(out);
        ISenderProtocolManager sp=new SenderProtocolManager(sender);
        IApplicationObserver app = new View(sp);
        ICommandConsumer comm=new Application(app);
        IMessageConsumer rpm=new ReceiverProtocolManager(comm);
        Reader reader=new Reader(in,"Quit");
        reader.setConsumer(rpm);
    }
}
