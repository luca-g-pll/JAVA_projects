public interface ICommandConsumer {

    void login(String username);
    void logout(String username);
    void setLetter(String letter);
    void action(String action);
    void winner(String winner);
    void ingamestatus(String opponent);
    void connectedUsers(String username);
    void request(String username);
    void response(String username);
    void error(String error);

}
