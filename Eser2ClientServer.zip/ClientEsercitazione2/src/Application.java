public class Application implements ICommandConsumer{
    IApplicationObserver ao;
    public Application(IApplicationObserver app){
        this.ao = app;
    }

    @Override
    public void login(String username) {
        ao.updateLogs("Join "+username);
    }

    @Override
    public void logout(String username) {
        ao.updateLogs("Quit "+username);
    }

    @Override
    public void setLetter(String letter) {
        ao.setLetter(letter);
    }

    @Override
    public void action(String data) {
        String[] datas = data.split("&");
        ao.updateField(datas[0], datas[1]);
    }

    @Override
    public void winner(String winner) {
        ao.winner(winner);
        ao.resetField();

    }

    @Override
    public void ingamestatus(String opponent) {
        ao.ingamestatus(opponent);
    }

    @Override
    public void connectedUsers(String info) {
        ao.updateUsers(info);
    }

    @Override
    public void request(String username) {
        ao.request(username);
    }

    @Override
    public void response(String ans) {
        String[] dati = ans.split("\\$");
        if(dati[1].equals("YES")){
            ao.obtainLetter();
            ao.initGame();
        }else{
            ao.refusedGame(dati[0]);
        }
    }

    @Override
    public void error(String error) {
        ao.error(error);
    }

}
