import io.Sender;

import java.util.*;

public class SenderProtocolManager implements ISenderProtocolManager{
    private Sender sender;
    Map<Integer, String> errori;
    Map<Integer, String> status;

    SenderProtocolManager(Sender s) {
        this.sender = s;
        this.errori = new HashMap<>();
        this.status = new HashMap<>();
        errori.put(101, "MissingParameter");
        errori.put(102, "UnknownCommand");
        errori.put(103, "UserAlreadyConnected");

        status.put(201, "LoginOK");
    }


    @Override
    public void sendUserList(Set<String> map) {
        StringBuilder res = new StringBuilder("ConnectedUsers*");
        for (String key : map) {
            res.append(key).append("$");
        }
        sender.send(res.substring(0, res.length()-1));
    }

    @Override
    public void inviaAzione(String azione) {
        sender.send("Azione*"+azione); //azione = "<riga>#<colonna>&X
    }

    @Override
    public void sendLogin(String username) {
        sender.send("Login*"+username);
    }

    public void sendMessage(String username, String message) {
        sender.send("Message*" + username + "#" + message);
    }

    @Override
    public void sendWinner(String winnerLetter) {
        sender.send("Winner*"+winnerLetter);
    }

    @Override
    public void sendInGameStatus(String opponent) {
        sender.send("InGameStatus*"+opponent);
    }

    @Override
    public void inviaRichiesta(String currUser){
        sender.send("Richiesta*"+currUser);
    }

    @Override
    public void inviaResponse(String currUser, String stato) {
        sender.send("Response*"+currUser+"$"+stato);
    }

    @Override
    public void inviaLettera(String letter) {
        sender.send("Letter*"+letter);
    }

    public void sendLogout(String username) {
        sender.send("Logout*" + username);
    }

    @Override
    public void status(int code) {
        sender.send("Status*"+status.get(code));
    }

    public void close() {
        sender.close();
    }

    public void errore(int code) {
        sender.send("Errore*" + errori.get(code));
    }
}
