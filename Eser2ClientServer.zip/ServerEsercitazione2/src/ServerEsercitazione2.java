import io.IMessageConsumer;
import io.Sender;
import io.Reader;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

public class ServerEsercitazione2 {
    public static void main(String[] args) throws IOException {
        Map<String, ISenderProtocolManager> users = new HashMap<>();

        ServerSocket ss = new ServerSocket(60000);
        while (true){
            Socket s = ss.accept();
            PrintWriter out = new PrintWriter(s.getOutputStream());
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
            Sender sender = new Sender(out);
            Reader reader = new Reader(in, "quit");
            ISenderProtocolManager sp = new SenderProtocolManager(sender);
            ICommandConsumer app = new Application(sp, users);
            IMessageConsumer rp = new ReceiverProtocolManager(app);
            reader.setConsumer(rp);
        }
    }
}
