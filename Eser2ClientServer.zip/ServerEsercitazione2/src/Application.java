import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Application implements ICommandConsumer{
    ISenderProtocolManager sp;
    Map<String, ISenderProtocolManager> users;
    String user;

    public Application(ISenderProtocolManager s, Map<String, ISenderProtocolManager> users){
        this.sp = s;
        this.users = users;
    }

    @Override
    public void login(String username) {
        this.user = username;
        if(users.containsKey(username)){
            errore(103);
        }else{
            users.put(username, sp);
            status(201);
            for (String s: users.keySet()) {
                if(!s.equals(username)) {
                    users.get(s).sendLogin(username);
                }
            }

            for (ISenderProtocolManager s: users.values()) {
                s.sendUserList(users.keySet());
            }
        }
    }

    @Override
    public void logout(String username) {
        users.remove(username);
        for (ISenderProtocolManager s: users.values()) {
            s.sendLogout(this.user);
            s.sendUserList(users.keySet());
        }

    }

    @Override
    public void letter(String mess) {
        String[] data = mess.split("\\$");
        users.get(data[0]).inviaLettera(data[1]);
    }

    @Override
    public void winner(String winner) {
        String[] opponentAndWinner = winner.split("\\$");
        users.get(opponentAndWinner[0]).sendWinner(opponentAndWinner[1]);
    }

    @Override
    public void ingame(String opponent) {
        users.get(opponent).sendInGameStatus(this.user);
    }

    @Override
    public void message(String message) {
        String[] dati = message.split("\\$");
        String usernameDest = dati[0];
        String messageBody = dati[1];

        users.get(usernameDest).sendMessage(this.user,messageBody);
    }

    @Override
    public void azione(String data) {
        String[] datas = data.split("\\$");
        users.get(datas[0]).inviaAzione(datas[1]); //Azione*opponent$0#1&X
    }

    @Override
    public void response(String status) {
        String[] data = status.split("\\$"); //Response*nome$risposta
        users.get(data[0]).inviaResponse(this.user, data[1]);
    }

    @Override
    public void richiestaGioco(String usernameDest) {
        users.get(usernameDest).inviaRichiesta(this.user);
    }


    @Override
    public void status(int code) {
        sp.status(code);
    }

    @Override
    public void errore(int code) {
        sp.errore(code);
    }

    @Override
    public void close() {
        users.remove(user);
        sp.close();
    }
}
