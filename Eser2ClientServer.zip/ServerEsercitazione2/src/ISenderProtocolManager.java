import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface ISenderProtocolManager {
    void sendUserList(Set<String> map);
    void inviaAzione(String azione);
    void sendLogin(String username);
    void inviaRichiesta(String currUser);
    void inviaResponse(String currUser, String stato);
    void inviaLettera(String letter);
    void sendMessage(String username, String message);
    void sendWinner(String winnerLetter);
    void sendInGameStatus(String opponent);
    void sendLogout(String username);
    void status(int code);
    void errore(int code);
    void close();


}
