import io.IMessageConsumer;

public class ReceiverProtocolManager implements IMessageConsumer {
    ICommandConsumer c;

    ReceiverProtocolManager(ICommandConsumer c) {
        this.c = c;
    }

    @Override
    public void consumeMessage(String s) {
        System.out.println(s);
        String[] s1 = s.split("\\*");
        if (s1.length == 2) {
            switch (s1[0].toLowerCase()) {
                case "login" -> {
                    c.login(s1[1]);
                }
                case "message" -> {
                    c.message(s1[1]);
                }
                case "azione" -> {
                    c.azione(s1[1]);
                }
                case "response" -> {
                    c.response(s1[1]);
                }
                case "richiesta" -> {
                    c.richiestaGioco(s1[1]);
                }
                case "logout" -> {
                    c.logout(s1[1]);
                }
                case "letter" -> {
                    c.letter(s1[1]);
                }
                case "winner" -> {
                    c.winner(s1[1]);
                }
                case "ingame" -> {
                    c.ingame(s1[1]);
                }
                default -> {
                    c.errore(102);
                }
            }
        } else {
            c.errore(101);
        }
    }
}
