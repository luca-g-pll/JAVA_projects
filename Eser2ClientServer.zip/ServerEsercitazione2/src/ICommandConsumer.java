public interface ICommandConsumer {

    void login(String username);
    void logout(String username);
    void letter(String mess);
    void winner(String winner);
    void ingame(String opponent);
    void message(String message);
    void azione(String data);
    void response(String status);
    void richiestaGioco(String usernameDest);
    void status(int code);
    void errore(int code);
    void close();
}
