//
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class GraphicView extends JFrame {

    private JFrame fr1 = new JFrame();
    private JFrame fr2  = new JFrame();;

    private JRadioButton[] jRadioFr1 = new JRadioButton[50];// i primi 50 JSONObject
    private String[] s1;
    private ArrayList<Pezzo> arrayListPezzo;
    private ArrayList<String> s2 = new ArrayList<String>();
    private ButtonGroup bg;
    DefaultListModel<String> listModel = new DefaultListModel<String>();

    //metodo per la creazione dei buttonJRadio (in questo caso i  primi 50)
    private void createJRadio(){
        this.bg = new ButtonGroup();

        for(int i = 0; i < jRadioFr1.length; i++) {
            this.jRadioFr1[i] = new JRadioButton(this.arrayListPezzo.get(i).getInventario());
            this.bg.add(this.jRadioFr1[i]);//per rendere selezionabile un solo elemento

            this.jRadioFr1[i].addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    returnInformation();
                }
            });
            this.fr1.add(this.jRadioFr1[i]);

        }
    }

    //metodo per la visualizzazione su fr2 --> dei dati spedifici al jRadio selezionato in fr1
    private void returnInformation(){

        int valoreSelezionato = -1;

        for(int i = 0; i < jRadioFr1.length; i++) //per i prmi 50 pezzi prendo il pezzo selezionato
            //if --> restituisce il valore dell'indice del valore dell'indice selezionato
            valoreSelezionato = (jRadioFr1[i].isSelected() ? i : valoreSelezionato); //operazione ternaria di if

        //controllare quale stringa dell'arraystring contiene il valore selezionato
            for(int i = 0; i < s1.length; i++) {

                //nel caso lo contenga l'if, metterà nel jlist i dati del pezzo specifico
                if(this.s1[i].contains(this.jRadioFr1[valoreSelezionato].getText())) {

                    this.listModel.addElement(this.s1[i]);//aggiungo gli elementi al modello della lista

                    JList<String> listPezzi = new JList<>(listModel);
                    // |
                    // v
                    listPezzi.setBounds(20,20,this.fr2.getWidth()-30,this.fr2.getHeight()-30);
                    this.fr2.add(listPezzi);
                    listPezzi.setVisible(true);
                    this.fr2.setVisible(true);

                    JScrollPane scroller = new JScrollPane(listPezzi);

                    scroller.setSize(listPezzi.getWidth(),listPezzi.getHeight()-12);

                    scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
                    scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

                    fr2.getContentPane().add(scroller); //aggiunta dello scroller (laterali)

                    this.fr2.setVisible(true);//per far vedere le nuove modifiche sul frame
                    break;//sto improvviso del ciclo
                }
            }
    }

    private void settingsFrame1(){
        //setting di fr1
            fr1.setTitle("Visualizzazione identificativi pezzi");
            fr1.setSize(500,650);
            fr1.setResizable(false);
            fr1.setLayout(new GridLayout(10,5, 2, 2));
            fr1.setLocation(250,100);
            //termina programma se chiudi schermata
            fr1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void settingsFrame2(){
        //setting di fr2
            fr2.setTitle("Visualizzazione dati del pezzo specifico");
            fr2.setSize(700, 1000);
            fr2.setResizable(false);
            fr2.setVisible(true);
            fr2.setLayout(null);
            fr2.setLocation(900, 50);
            //termina programma se chiudi schermata
            fr2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

//metodo per la visualizzazione dei frame e annessi funzionamenti
    public void view(ArrayList arrayList, String[] s){

        this.arrayListPezzo = arrayList;
        this.s1  = s;
        this.settingsFrame1();
        this.settingsFrame2();
        this.createJRadio();
        fr1.setVisible(true);

    }
}
